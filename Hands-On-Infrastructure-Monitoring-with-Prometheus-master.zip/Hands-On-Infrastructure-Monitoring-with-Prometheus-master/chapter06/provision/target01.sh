#!/usr/bin/env bash

/vagrant/chapter06/provision/blackbox_exporter.sh
/vagrant/chapter06/provision/mtail_exporter.sh
/vagrant/chapter06/provision/grok_exporter.sh
